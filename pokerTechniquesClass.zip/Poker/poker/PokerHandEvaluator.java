package poker;

public class PokerHandEvaluator {
	private static int rank(Card[] cards, int cardCounter) {
		int count = 0;
		if (cardCounter == cards[0].getValue()) { // cardCounter takes value from cards[i].getValue
			count++;
		}
		if (cardCounter == cards[1].getValue()) {
			count++;
		}
		if (cardCounter == cards[2].getValue()) {
			count++;
		}
		if (cardCounter == cards[3].getValue()) {
			count++;
		}
		if (cardCounter == cards[4].getValue()) {
			count++;
		}

		return count;

	}

	private static boolean hasNumber(Card[] cards, int number) {
		for (int i = 0; i < cards.length; i++) {
			if (cards[i].getValue() == number) {
				return true;
			}

		}
		return false;
	}

	public static boolean hasPair(Card[] cards) {
		for (int i = 0; i < cards.length; i++) {
			if (rank(cards, cards[i].getValue()) >= 2) {
				return true;
			}

		}
		return false;

	}

	public static boolean hasTwoPair(Card[] cards) {
		if (hasFourOfAKind(cards)) {
			return false;
		}
		int[] newArray = new int[13];
		int counter = 0;
		for (int i = 0; i < cards.length; i++) {
			newArray[cards[i].getValue() - 1]++;
		}
		for (int a = 0; a < newArray.length; a++) {
			if (newArray[a] >= 2) {
				counter++;
			}
			if (counter == 2) {
				return true;
			}

		}

		return false;
	}

	public static boolean hasThreeOfAKind(Card[] cards) {
		for (int i = 0; i < cards.length; i++) {
			if (rank(cards, cards[i].getValue()) >= 3) {
				return true;
			} //

		}
		return false;

	}

	public static boolean hasStraight(Card[] cards) {// five cards of the same suit, but not in a sequence {9,5,6,7}

		if (hasFourOfAKind(cards)) {
			return false;
		}
		int min = 14;
		for (int i = 0; i < cards.length; i++) {
			if (min >= cards[i].getValue()) {
				min = cards[i].getValue();

			}
		}
		if (hasNumber(cards, 1) && hasNumber(cards, 10) && hasNumber(cards, 11) 
				&& hasNumber(cards, 12)
				&& hasNumber(cards, 13)) {
			return true;

		}
		for (int a = min; a < min + 5; a++) {
			if ((!hasNumber(cards, a))) {
				return false;
			}

		}
		return true;
	}

	public static boolean hasFlush(Card[] cards) { // (3,3) , (7,3), (8,3)
		int count = 0;
		for (int i = 0; i < cards.length; i++) { // ( 4,3) , (10,2)
			if (cards[i].getSuit() == cards[0].getSuit()) { // card[i] is to access all 52 cards in the deck
				count++;
			}
			if (cards[i].getSuit() == cards[1].getSuit()) {
				count++;
			}
			if (cards[i].getSuit() == cards[2].getSuit()) {
				count++;
			}
			if (cards[i].getSuit() == cards[3].getSuit()) {
				count++;
			}
			if (cards[i].getSuit() == cards[4].getSuit()) {
				count++;
			}
			if (count < 5) {// since i'm looping through all 52 , if count is not equal to 5 for cards[0/i]
							// i need to reset the counter.
				count = 0;
			}
		}
		if (count >= 5) {
			return true;
		}
		return false;

	}

	public static boolean hasFullHouse(Card[] cards) {
		if (hasTwoPair(cards) && hasThreeOfAKind(cards)) { // [4,4,10,10,4]
			return true;
		}
		return false;
	}

	public static boolean hasFourOfAKind(Card[] cards) {
		for (int i = 0; i < cards.length; i++) {
			if (rank(cards, cards[i].getValue()) >= 4) {
				return true;
			}

		}
		return false;

	}

	public static boolean hasStraightFlush(Card[] cards) {
		if (hasFlush(cards) && hasStraight(cards)) {
			return true;
		}
		return false;
	}

}
